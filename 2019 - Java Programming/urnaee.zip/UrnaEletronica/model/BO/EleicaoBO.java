package BO;

public class EleicaoBO {

}
