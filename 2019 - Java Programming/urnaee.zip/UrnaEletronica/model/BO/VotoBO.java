package BO;

public class VotoBO {

}
