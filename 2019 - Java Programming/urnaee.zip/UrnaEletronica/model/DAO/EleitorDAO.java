package DAO;

import DTO.Eleitor;
import interfaces.lPersistenciaEleitor;

public class EleitorDAO implements lPersistenciaEleitor{

	@Override
	public void inserir(Eleitor eleitor) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void atualizar(Eleitor eleitor) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deletar(Eleitor eleitor) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procurar(Eleitor eleitor) {
		// TODO Auto-generated method stub
		
	}

}
