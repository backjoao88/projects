package DAO;

import DTO.Candidato;
import interfaces.IPersistenciaCandidato;

public class VotoDAO implements IPersistenciaCandidato{

	@Override
	public void inserir(Candidato candidato) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void atualizar(Candidato candidato) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deletar(Candidato candidato) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void procurar(Candidato candidato) {
		// TODO Auto-generated method stub
		
	}

}
