package BO;

public class EleitorBO {

}
