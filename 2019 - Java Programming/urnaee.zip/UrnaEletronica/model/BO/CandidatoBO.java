package BO;

public class CandidatoBO {

}
